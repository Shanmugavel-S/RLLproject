import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent implements OnInit {

  customerdetails:Customer;
  isFormSubmitted : boolean;
  isValid : boolean;

  signup(signupForm : NgForm) {
    if (signupForm.invalid) {      
      return;      
    }
    
    this.isValid=true;
    if(this.isValid==true){
    this._customerService.addCustomer(this.customerdetails).subscribe(x => {
    });
    alert("Customer Registration Successful!");
    this._router.navigate(['/CustomerLogin'])
  }
}
    
  constructor(private _customerService:CustomerService , private _router : Router) {
this.customerdetails=new Customer();
this.isFormSubmitted = false;
this.isValid=false;

   }

  //    this._customerService.addCustomer(this.customerdetails).subscribe(x => {
  //    });
  //    alert("customer added");
   
  // }

  ngOnInit(): void {
  }

}
